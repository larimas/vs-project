﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MultiTierProject
{
    public partial class Form2 : Form
    {
        internal enum Modes
        {
            INSERT,
            UPDATE
        }

        internal static Form2 current;

        private Modes mode = Modes.INSERT;
        private string oldCId = "";
        private string oldCName = "";

        public Form2()
        {
            current = this;
            InitializeComponent();
        }

        internal void Start(Modes m, DataGridViewSelectedRowCollection c)
        {
            mode = m;

            if (mode == Modes.INSERT)
            {
                cboxStudentID.DisplayMember = "StId";
                cboxStudentID.ValueMember = "StId";
                cboxStudentID.DataSource = Data.Students.GetStudents();
                cboxStudentID.SelectedItem = null;
                cboxStudentID.Enabled = true;

                txtStudentName.Text = "";
                txtStudentName.ReadOnly = true;

                cboxCourseID.DisplayMember = "CId";
                cboxCourseID.ValueMember = "CId";
                cboxCourseID.DataSource = Data.Courses.GetCourses();

                cboxStudentID.Enabled = true;
                cboxCourseID.SelectedItem = null;

                txtCourseName.Text = "";
                txtCourseName.ReadOnly = true;
            }

            if (mode == Modes.UPDATE)
            {

                cboxStudentID.DisplayMember = "StId";
                cboxStudentID.ValueMember = "StId";
                cboxStudentID.DataSource = Data.Students.GetStudents();
                cboxStudentID.SelectedValue = c[0].Cells["StId"].Value;
                cboxStudentID.Enabled = false;

                txtStudentName.Text = "" + c[0].Cells["StName"].Value;
                txtStudentName.ReadOnly = true;

                cboxCourseID.DisplayMember = "CId";
                cboxCourseID.ValueMember = "CId";
                cboxCourseID.DataSource = Data.Courses.GetCourses();
                cboxCourseID.Enabled = true;
                cboxCourseID.SelectedValue = c[0].Cells["CId"].Value;
                txtCourseName.Text = "" + c[0].Cells["CName"].Value;
                txtCourseName.ReadOnly = true;

                oldCId = "" + c[0].Cells["CId"].Value;
                oldCName = "" + c[0].Cells["CName"].Value;

            }

            ShowDialog();
        }

        private void cboxStudentID_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cboxStudentID.SelectedItem != null)
            {
                var a = from r in Data.Students.GetStudents().AsEnumerable()
                        where r.Field<String>("StId").Equals(cboxStudentID.SelectedValue)
                        select new
                        {
                            StId = r.Field<string>("StId"),
                            StName = r.Field<string>("StName")
                        };
                cboxStudentID.Text = a.Single().StId;
                txtStudentName.Text = "" + a.Single().StName;
            }
        }

        private void cboxCourseID_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cboxCourseID.SelectedItem != null)
            {
                var a = from r in Data.Courses.GetCourses().AsEnumerable()
                        where r.Field<String>("CId").Equals(cboxCourseID.SelectedValue)
                        select new
                        {
                            CId = r.Field<string>("CId"),
                            CName = r.Field<string>("CName")
                        };
                cboxCourseID.Text = a.Single().CId;
                txtCourseName.Text = "" + a.Single().CName;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Data.Enrollments enroll = new Data.Enrollments();

            if (mode == Modes.INSERT)
            {

                if (cboxCourseID.SelectedItem != null && cboxStudentID.SelectedItem != null)
                {
                    enroll.StId = cboxStudentID.Text;
                    enroll.StName = txtStudentName.Text;
                    enroll.CId = cboxCourseID.Text;
                    enroll.CName = txtCourseName.Text;
                    enroll.FinalGrade = null;
                }
                else
                {
                    MessageBox.Show("Student ID and Course ID selected");
                    return;
                }

            }
            if (mode == Modes.UPDATE)
            {
                enroll.StId = cboxStudentID.Text;
                enroll.StName = txtStudentName.Text;
                enroll.CId = cboxCourseID.Text;
                enroll.CName = txtCourseName.Text;
                enroll.oldCId = oldCId;
                enroll.oldCName = oldCName;
                enroll.FinalGrade = null;

            }

            if (mode == Modes.INSERT) { Data.Enrollments.InsertData(enroll); }
            if (mode == Modes.UPDATE) { Data.Enrollments.UpdateData(enroll); }

            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
            MultiTierProject.Form1.hasError = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //
        }
    }
}
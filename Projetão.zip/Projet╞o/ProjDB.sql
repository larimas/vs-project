IF db_id('College1en') IS NULL 
    CREATE DATABASE College1en;
GO

USE College1en;
GO

CREATE TABLE Programs(
    ProgId VARCHAR(5) NOT NULL,
    ProgName VARCHAR(50) NOT NULL UNIQUE, 
    CONSTRAINT PK_Programs PRIMARY KEY (ProgId) 
);
GO

CREATE TABLE Courses(
    CId VARCHAR(7) NOT NULL,
    CName VARCHAR(50) NOT NULL,
    ProgId VARCHAR(5) NOT NULL,
    CONSTRAINT PK_Courses PRIMARY KEY (CId),
    CONSTRAINT FK_Courses_Programs 
        FOREIGN KEY(ProgId) REFERENCES Programs (ProgId)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
GO

CREATE TABLE Students(
    StId VARCHAR(10) NOT NULL,
    StName VARCHAR(50) NOT NULL,
    ProgId VARCHAR(5) NOT NULL,
    CONSTRAINT PK_Students PRIMARY KEY (StId),
    CONSTRAINT FK_Students_Programs 
        FOREIGN KEY(ProgId) REFERENCES Programs (ProgId)
        ON DELETE NO ACTION
        ON UPDATE CASCADE
);
GO

CREATE TABLE Enrollments(
    StId VARCHAR(10) NOT NULL,
    CId VARCHAR(7) NOT NULL,
    FinalGrade INT,
    CONSTRAINT PK_Enrollments PRIMARY KEY (StId, CId), 
    CONSTRAINT FK_Enrollments_Students 
        FOREIGN KEY(StId) REFERENCES Students (StId)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_Enrollments_Courses 
        FOREIGN KEY(CId) REFERENCES Courses (CId)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
);
GO
/*
8. The CId of a course cannot be updated if there are enrollments to that course.
*/

INSERT Programs (ProgId, ProgName) VALUES ('P0001', 'Journalism');
INSERT Programs (ProgId, ProgName) VALUES ('P0002', 'Design');
INSERT Programs (ProgId, ProgName) VALUES ('P0003', 'Law');
INSERT Programs (ProgId, ProgName) VALUES ('P0004', 'Photography');
GO

INSERT Courses (CId, CName, ProgId) VALUES ('C000001', 'Audiovisual', 'P0001');
INSERT Courses (CId, CName, ProgId) VALUES ('C000002', 'Sociology', 'P0001');
INSERT Courses (CId, CName, ProgId) VALUES ('C000003', 'Photo & Video', 'P0001');
INSERT Courses (CId, CName, ProgId) VALUES ('C000004', 'Filosofia', 'P0001');
INSERT Courses (CId, CName, ProgId) VALUES ('C000005', 'Draw', 'P0002');
INSERT Courses (CId, CName, ProgId) VALUES ('C000006', 'Shapes', 'P0002');
INSERT Courses (CId, CName, ProgId) VALUES ('C000007', 'Law', 'P0003');
INSERT Courses (CId, CName, ProgId) VALUES ('C000008', 'Order', 'P0003');
INSERT Courses (CId, CName, ProgId) VALUES ('C000009', 'Photoshop', 'P0004');
INSERT Courses (CId, CName, ProgId) VALUES ('C000010', 'Model', 'P0004');

GO

INSERT Students (StId, StName, ProgId) VALUES ('S000000001', 'Carolina', 'P0001');
INSERT Students (StId, StName, ProgId) VALUES ('S000000002', 'Fernando', 'P0001');
INSERT Students (StId, StName, ProgId) VALUES ('S000000003', 'Gabriela', 'P0002');
INSERT Students (StId, StName, ProgId) VALUES ('S000000004', 'Cesar', 'P0002');
INSERT Students (StId, StName, ProgId) VALUES ('S000000005', 'Clarice', 'P0003');
INSERT Students (StId, StName, ProgId) VALUES ('S000000006', 'Aline', 'P0003');
INSERT Students (StId, StName, ProgId) VALUES ('S000000007', 'Larissa', 'P0004');
INSERT Students (StId, StName, ProgId) VALUES ('S000000008', 'Pietra', 'P0004');
GO

INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000001', 'C000001', 100);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000001', 'C000002', 95);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000002', 'C000003', 90);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000002', 'C000004', 85);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000003', 'C000005', 80);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000003', 'C000006', 75);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000004', 'C000005', 70);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000004', 'C000006', 65);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000005', 'C000007', 60);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000005', 'C000008', 59);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000006', 'C000007', 99);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000006', 'C000008', 88);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000007', 'C000009', 77);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000007', 'C000010', 66);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000008', 'C000009', 50);
INSERT Enrollments (StId, CId, FinalGrade) VALUES ('S000000008', 'C000010', null);

GO

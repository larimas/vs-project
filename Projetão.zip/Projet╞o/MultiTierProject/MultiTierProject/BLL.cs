﻿using Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLayer

{
    internal class Students
    {
        internal static int UpdateStudents()
        {
            DataSet ds = Data.DataTables.getDataSet();

            DataTable dt = ds.Tables["Students"]
                              .GetChanges(DataRowState.Added | DataRowState.Modified);
            if ((dt != null) && (dt.Rows.Count == 1))
            {
                string studentsRegex = "^S\\d{9}$";
                string programsRegex = "^P\\d{4}$";
                DataRow r = dt.Rows[0];
                if (Regex.IsMatch(("" + r["StId"]), studentsRegex) && !(("" + r["StName"]).Equals("")) && Regex.IsMatch(("" + r["ProgId"]), programsRegex))
                {
                    return Data.Students.UpdateStudents();
                }
                else
                {
                    MultiTierProject.Form1.UIMessage("Students Insertion/Update rejected: Student Id must have S (uppercase) and followed by 9 digits\nProgId must have P (uppercase) and followed by 4 digits\"");
                    ds.Tables["Students"].RejectChanges();
                    return -1;
                }
            }
            else
            {
                return Data.Students.UpdateStudents();
            }

        }
    }


    internal class Enrollment
    {
        internal static int UpdateEnrollment()
        {

            DataSet ds = Data.DataTables.getDataSet();

            DataTable dt = ds.Tables["Enrollments"]
                              .GetChanges(DataRowState.Added | DataRowState.Modified);
            if ((dt != null) && (dt.Rows.Count == 1))
            {
                DataRow r = dt.Rows[0];
                if (r["FinalGrade"].ToString().Equals("") || (Convert.ToInt32(r["FinalGrade"]) >= 0 && Convert.ToInt32(r["FinalGrade"]) <= 100))
                {
                    return Data.Enrollments.UpdateEnrollments();
                }
                else
                {
                    MultiTierProject.Form1.msgInvalidFinalGrade();
                    ds.Tables["Enrollment"].RejectChanges();
                    return -1;
                }
            }
            else
            {
                return Data.Enrollments.UpdateEnrollments();
            }
        }

        internal static bool IsValidInsert(Data.Enrollments enroll)
        {
            DataSet ds = Data.DataTables.getDataSet();

            DataTable dtStudents = ds.Tables["Students"];
            DataTable dtCourses = ds.Tables["Courses"];

            if (((dtStudents != null) && (dtStudents.Rows.Count > 0)) && ((dtCourses != null) && (dtCourses.Rows.Count > 0)))
            {
                DataRow studentRow = dtStudents.Rows.Find(enroll.StId);
                DataRow courseRow = dtCourses.Rows.Find(enroll.CId);
                if (studentRow != null)
                {
                    if (courseRow != null)
                    {
                        if (studentRow["ProgId"].Equals(courseRow["ProgId"]))
                        {
                            return true;
                        }
                    }
                    MultiTierProject.Form1.UIMessage("Business Rules: Addition/modification rejected: Course must be in the same Program of the Student.");
                    return false;
                }
                MultiTierProject.Form1.UIMessage("Business Rules: Addition/modification rejected: Course must be in the same Program of the Student.");
                return false;
            }
            MultiTierProject.Form1.UIMessage("Business Rules: Addition/modification rejected: Course must be in the same Program of the Student.");
            return false;
        }

        internal static bool IsValidUpdate(Data.Enrollments enroll)
        {
            DataSet ds = Data.DataTables.getDataSet();

            DataTable dtEnrollment = ds.Tables["Enrollment"];
            DataTable dtStudents = ds.Tables["Students"];
            DataTable dtCourses = ds.Tables["Courses"];

            if (((dtStudents != null) && (dtStudents.Rows.Count > 0)) && ((dtCourses != null) && (dtCourses.Rows.Count > 0)))
            {
                DataRow studentRow = dtStudents.Rows.Find(enroll.StId);
                DataRow courseRow = dtCourses.Rows.Find(enroll.CId);
                DataRow courseOldRow = dtCourses.Rows.Find(enroll.oldCId);
                if (studentRow != null)
                {
                    if (courseOldRow != null)
                    {
                        foreach (DataRow enrollRow in dtEnrollment.Rows)
                        {

                            if (studentRow["ProgId"].Equals(courseRow["ProgId"]) && (enrollRow["StId"].Equals(enroll.StId) && enrollRow["CId"].Equals(enroll.oldCId)) && enrollRow["FinalGrade"].ToString().Equals(""))
                            {
                                return true;
                            }
                        }

                    }
                }
            }
            MultiTierProject.Form1.UIMessage("Business Rules: Addition/modification rejected: Course must be in the same Program of the Student and final grade should be null.");
            return false;
        }

        internal static bool IsValidFinalGrade(Data.Enrollments enroll)
        {
            DataSet ds = Data.DataTables.getDataSet();

            DataTable dtEnrollment = ds.Tables["Enrollment"];

            if (enroll.FinalGrade.ToString().Equals("") || (enroll.FinalGrade >= 0 && enroll.FinalGrade <= 100))
            {
                foreach (DataRow enrollRow in dtEnrollment.Rows)
                {
                    if ((enrollRow["StId"].Equals(enroll.StId) && enrollRow["CId"].Equals(enroll.CId)))
                    {
                        return true;
                    }
                }
            }

            MultiTierProject.Form1.UIMessage("Business Rules: Final Grade Modification rejected. Final Grade can be empty or int number between 0 - 100");
            return false;
        }


        internal static bool IsValidDelete(List<Data.Enrollments> lEnrollment)
        {
            DataSet ds = Data.DataTables.getDataSet();

            DataTable dtEnrollment = ds.Tables["Enrollment"];

            foreach (Data.Enrollments enrollElement in lEnrollment)
            {
                if (!(enrollElement.FinalGrade.ToString().Equals("")))
                {
                    MultiTierProject.Form1.UIMessage("Business Rules: Deletion rejected. The One or more Final Grade is already set.");
                    return false;
                }
            }
            return true;

        }

    }




    internal class Courses
    {
        internal static int UpdateCourses()
        {

            DataSet ds = Data.DataTables.getDataSet();

            DataTable dt = ds.Tables["Courses"]
                              .GetChanges(DataRowState.Added | DataRowState.Modified);
            if ((dt != null) && (dt.Rows.Count == 1))
            {
                string coursesRegex = "^C\\d{6}$";
                string programsRegex = "^P\\d{4}$";
                DataRow r = dt.Rows[0];
                if (Regex.IsMatch(("" + r["CId"]), coursesRegex) && !(("" + r["CName"]).Equals("")) && Regex.IsMatch(("" + r["ProgId"]), programsRegex))
                {
                    return Data.Courses.UpdateCourses();
                }
                else
                {
                    MultiTierProject.Form1.UIMessage("Courses Insertion/Update rejected: Course ID must have C (uppercase) and followed by 6 digits\nProgId must have P (uppercase) and followed by 4 digits\"");
                    ds.Tables["Courses"].RejectChanges();
                    return -1;
                }
            }
            else
            {
                return Data.Courses.UpdateCourses();
            }

        }
    }

    internal class Programs
    {
        internal static int UpdatePrograms()
        {

            DataSet ds = Data.DataTables.getDataSet();

            DataTable dt = ds.Tables["Programs"]
                              .GetChanges(DataRowState.Added | DataRowState.Modified | DataRowState.Deleted);

            if ((dt != null) && (dt.Rows.Count == 1))
            {
                DataRow r = dt.Rows[0];
                if (r.RowState == DataRowState.Added || r.RowState == DataRowState.Modified)
                {
                    string programsRegex = "^P\\d{4}$";

                    if (Regex.IsMatch(("" + r["ProgId"]), programsRegex) && !(("" + r["ProgName"]).Equals("")))
                    {
                        return Data.Programs.UpdatePrograms();
                    }
                    else
                    {
                        MultiTierProject.Form1.UIMessage("Programs Insertion/Update rejected: ProgID must have P (uppercase) and followed by 4 digits\"");
                        ds.Tables["Programs"].RejectChanges();
                        return -1;
                    }
                }

                else if (r.RowState == DataRowState.Deleted)
                {
                    var lines = ds.Tables["Students"].AsEnumerable()
                                     .Where(s => s.Field<string>("ProgId") == ("" + r["ProgId"]));
                    if (lines == null)
                    {
                        return Data.Programs.UpdatePrograms();
                    }
                    else
                    {
                        MultiTierProject.Form1.UIMessage("Programs Delete rejected: there are Students in the Program\"");
                        ds.Tables["Programs"].RejectChanges();
                        return -1;
                    }
                }
                else
                {
                    return Data.Programs.UpdatePrograms();
                }

            }
            else
            {
                return Data.Programs.UpdatePrograms();
            }

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MultiTierProject.Form2;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MultiTierProject
{
    public partial class Form3 : Form
    {
        internal static Form3 current;
        public Form3()
        {
            current = this;
            InitializeComponent();
        }

        internal void Start(DataGridViewSelectedRowCollection c)
        {
            cboxStudentID.DisplayMember = "StId";
            cboxStudentID.ValueMember = "StId";
            cboxStudentID.DataSource = Data.Students.GetStudents();
            cboxStudentID.SelectedValue = c[0].Cells["StId"].Value;
            cboxStudentID.Enabled = false;

            txtStudentName.Text = "" + c[0].Cells["StName"].Value;
            txtStudentName.ReadOnly = true;

            cboxCourseID.DisplayMember = "CId";
            cboxCourseID.ValueMember = "CId";
            cboxCourseID.DataSource = Data.Courses.GetCourses();
            cboxCourseID.Enabled = false;
            cboxCourseID.SelectedValue = c[0].Cells["CId"].Value;
            
            txtCourseName.Text = "" + c[0].Cells["CName"].Value;
            txtCourseName.ReadOnly = true;

            txtFinalGrade.Text = "" + c[0].Cells["Finalgrade"].Value;
            txtFinalGrade.ReadOnly = false;

            ShowDialog();

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Data.Enrollments enroll = new Data.Enrollments();

            enroll.StId = cboxStudentID.Text;
            enroll.StName = txtStudentName.Text;
            enroll.CId = cboxCourseID.Text;
            enroll.CName = txtCourseName.Text;
            if (!(txtFinalGrade.Text.Equals("")))
            {
                try { enroll.FinalGrade = int.Parse(txtFinalGrade.Text); }
                catch (Exception)
                {
                    MessageBox.Show("Final Grade must be an integer number.");
                    return;
                }
            }
            else
            {
                enroll.FinalGrade = null;
            }

            Data.Enrollments.ManageFinalGrade(enroll);

            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
            MultiTierProject.Form1.hasError = true;
        }
    }
}
